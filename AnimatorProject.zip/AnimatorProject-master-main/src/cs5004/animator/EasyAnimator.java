package cs5004.animator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import cs5004.animator.controller.AnimationControllerImpl;
import cs5004.animator.controller.IAnimationController;
import cs5004.animator.model.AnimationModelImpl;
import cs5004.animator.model.IAnimationModel;
import cs5004.animator.util.AnimationBuilder;
import cs5004.animator.util.AnimationReader;
import cs5004.animator.view.IAnimationView;
import cs5004.animator.view.ViewType;

import static cs5004.animator.view.FactoryView.makeView;

/** Program entry point for Animator application. */
public final class EasyAnimator {

  /**
   * Driver: main.
   *
   * @param args the string arguments passed in from the command line.
   * @throws IllegalArgumentException if the inputs are invalid.
   */
  public static void main(String[] args) throws IllegalArgumentException {
    String output = "";
    int speed = 1;
    String input = "";
    String viewType = "";

    if (args.length == 0) {
      throw new IllegalArgumentException("Invalid command input.");
    }

    for (int argsPosition = 0; argsPosition < args.length; argsPosition += 2) {
      if ("-in".equals(args[argsPosition])) {
        input = args[argsPosition + 1];
        if (!(input.endsWith(".txt"))) {
          throw new IllegalArgumentException("File invalid.");
        }
      } else if ("-out".equals(args[argsPosition])) {
        String tempOutput = args[argsPosition + 1];
        tempOutput = tempOutput.replace("out.", "");
        if (tempOutput.equals(ViewType.SVG.getViewString())
            || tempOutput.equals(ViewType.TEXT.getViewString())
            || tempOutput.equals(ViewType.GUI.getViewString())) {
          output = tempOutput;
        }
      } else if ("-view".equals(args[argsPosition])) {
        viewType = args[argsPosition + 1];
      } else if ("-speed".equals(args[argsPosition])) {
        try {
          speed = Integer.parseInt(args[argsPosition + 1]);
        } catch (NumberFormatException e) {
          throw new NumberFormatException("Invalid speed.");
        }
        if (speed < 1) {
          throw new IllegalArgumentException("Speed is invalid.");
        }
      } else {
        throw new IllegalArgumentException("Invalid command line");
      }
    }

    AnimationBuilder<IAnimationModel> builder;
    builder = new AnimationModelImpl.Builder();
    IAnimationModel model = builder.build();
    IAnimationView view = makeView(viewType, speed);

    IAnimationController controller = new AnimationControllerImpl(model, view);

    try {
      AnimationReader.parseFile(new InputStreamReader(new FileInputStream(input)), builder);
    } catch (FileNotFoundException error) {
      throw new IllegalArgumentException("File could not be found.");
    }
    if (output.equals("")) { // Look through and make necessary refactors
      controller.play(System.out);
    } else {
      try {
        FileWriter out = new FileWriter(output);
        controller.play(out);
        out.close();
      } catch (IOException e) {
        throw new IllegalStateException("Invalid output was provided");
      }
    }
  }
}
