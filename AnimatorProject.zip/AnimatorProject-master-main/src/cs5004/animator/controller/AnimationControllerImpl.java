package cs5004.animator.controller;

import cs5004.animator.shapes.IShape;
import cs5004.animator.view.IAnimationView;
import cs5004.animator.view.IViewControls;
import cs5004.animator.model.IAnimationModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;
import javax.swing.JSlider;
import javax.swing.Timer;

/**
 * This class implements the IAnimationController interface takes in the model and view, in order to
 * navigate the program.
 */
public class AnimationControllerImpl implements IAnimationController, IViewControls {
  private final IAnimationModel animationModel;
  private final IAnimationView animationView;
  private final Timer timer;
  private int tick;
  private boolean bool;

  /**
   * This is the constructor that constructs a Controller object.
   *
   * @param animationModel animation model
   * @param animationView animation view
   */
  public AnimationControllerImpl(IAnimationModel animationModel, IAnimationView animationView) {
    this.animationModel = Objects.requireNonNull(animationModel);
    this.animationView = Objects.requireNonNull(animationView);
    this.timer =
        new Timer(
            1,
                e -> {});

    this.animationView.setListener(this);

    this.animationView.setScreen(this.animationModel.getScreen());
    this.tick = 0;
  }

  /**
   * Method that plays the animation.
   *
   * @param appendable Appendable object
   */
  @Override
  public void play(Appendable appendable) {
    this.animationView.display(this.animationModel);
  }

  @Override
  public void start() {
    if (this.tick == 0) {
      this.timer.start();
    }
    //    if (this.tick > this.animationModel.getLastTick()) {
    //      this.tick = 0;
    //    }
  }

  @Override
  public void pause() {
    this.timer.stop();
  }

  @Override
  public void resume() {
    if (this.tick > 0) {
      this.timer.start();
    }
  }

  @Override
  public void restart() {
    this.tick = 0;
    this.timer.start();
  }

  @Override
  public void loop(boolean bool) {
    //    this.loop = bool;
    //    if (bool && this.animationModel.getLastTick() < this.tick) {
    //      this.timer.stop();
    //      this.tick = 0;
    //    }
  }

  @Override
  public void addShape(IShape shape) {}

  @Override
  public void removeShape(String identifier) {}

  @Override
  public void scrub(JSlider jSlider, int number) {
    Objects.requireNonNull(jSlider);
    //    jSlider.setMaximum(this.animationModel.getLastTick() - 1);
    this.tick = number;
    this.timer.stop();
    this.animationView.display(this.animationModel);
  }
}
