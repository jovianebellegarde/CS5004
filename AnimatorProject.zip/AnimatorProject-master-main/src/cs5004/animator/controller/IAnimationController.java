package cs5004.animator.controller;

/**
 * This class represents the Controller for theAnimator application.
 */
public interface IAnimationController {

  /**
   * Method that plays the animation.
   *
   * @param appendable Appendable object
   */
  void play(Appendable appendable);
}
