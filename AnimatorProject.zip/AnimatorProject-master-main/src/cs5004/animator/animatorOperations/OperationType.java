package cs5004.animator.animatorOperations;

/** An enum class for operation types. */
public enum OperationType {
  SCALE("Scale"),
  MOVE("Move"),
  PAINT("Paint");

  String operation;

  /**
   * String representation of OperationType.
   *
   * @param operation string representation of OperationType
   */
  OperationType(String operation) {
    this.operation = operation;
  }
}
