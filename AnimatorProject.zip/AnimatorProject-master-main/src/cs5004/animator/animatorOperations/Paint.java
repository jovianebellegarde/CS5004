package cs5004.animator.animatorOperations;

import java.awt.Color;
import java.util.Objects;

import cs5004.animator.shapes.IShape;
import cs5004.animator.util.TimeInterval;

/** A class that colors a Shape object. */
public class Paint extends AbstractAnimatorOperation {
  private final Color newColor;

  /**
   * Constructor method.
   *
   * @param newColor colors of shape
   * @param shape Shape object
   * @param timeInterval time elapsed
   * @throws IllegalArgumentException if color is null
   * @throws IllegalArgumentException if color is the same
   */
  public Paint(Color newColor, IShape shape, TimeInterval timeInterval) {
    super(OperationType.PAINT, shape, timeInterval);
    // Same color is invalid
    if (newColor == shape.getColor()) {
      throw new IllegalArgumentException("Color cannot be the same");
    }
    this.newColor = Objects.requireNonNull(newColor, "Color object is null");
  }

  /**
   * String representation of the Paint operation.
   *
   * @return string representation of the Paint operation.
   */
  @Override
  public String toString() {
    return "Shape "
        + this.getShape().getName()
        + " changes color from "
        + "("
        + this.getShape().getColor().getRed()
        + ","
        + this.getShape().getColor().getGreen()
        + ","
        + this.getShape().getColor().getBlue()
        + ")"
        + " to "
        + "("
        + this.newColor.getRed()
        + ","
        + this.newColor.getGreen()
        + ","
        + this.newColor.getBlue()
        + ") "
        + this.getTimeInterval().toStringAnimation();
  }
}
