package cs5004.animator.animatorOperations;

import java.util.Objects;

import cs5004.animator.shapes.IShape;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;

/** A class that resizes a Shape object. */
public class Scale extends AbstractAnimatorOperation {
  private final Size newSize;

  /**
   * Constructor method.
   *
   * @param newSize size of shape
   * @param shape Shape object
   * @param timeInterval time elapsed
   */
  public Scale(Size newSize, IShape shape, TimeInterval timeInterval) {
    super(OperationType.SCALE, shape, timeInterval);
    this.newSize = Objects.requireNonNull(newSize, "Size object is null");
  }

  /**
   * String representation of the Scale operation.
   *
   * @return string representation of the Scale operation.
   */
  @Override
  public String toString() {
    return "Shape "
        + this.getShape().getName()
        + " scales from "
        + this.getShape().getSize().toString()
        + " to "
        + this.newSize.toString()
        + " "
        + this.getTimeInterval().toStringAnimation();
  }
}
