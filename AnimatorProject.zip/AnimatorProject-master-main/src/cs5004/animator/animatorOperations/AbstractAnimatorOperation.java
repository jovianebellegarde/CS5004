package cs5004.animator.animatorOperations;

import java.util.Objects;

import cs5004.animator.shapes.IShape;
import cs5004.animator.util.TimeInterval;

/** An abstract class for cs5004.animator operation types. */
public abstract class AbstractAnimatorOperation implements AnimatorOperation {
  private final OperationType operationType;
  private final IShape shape;
  private final TimeInterval timeInterval;

  /**
   * Constructor method.
   *
   * @param operationType OperationType enum
   * @param shape Shape object
   * @param timeInterval time elapsed
   * @throws IllegalArgumentException if operation time is invalid
   */
  public AbstractAnimatorOperation(
      OperationType operationType, IShape shape, TimeInterval timeInterval)
      throws IllegalArgumentException {
    // Null Checks
    try {
      this.operationType = Objects.requireNonNull(operationType);
      this.shape = Objects.requireNonNull(shape);
      this.timeInterval = Objects.requireNonNull(timeInterval);
    } catch (NullPointerException exception) {
      throw new IllegalArgumentException("Null objects were passed in");
    }
    // Check animationOperation's timeInterval is valid with the Shape's timeInterval
    if (invalidTimeInterval()) {
      throw new IllegalArgumentException("Invalid timeInterval");
    }
  }

  /**
   * Helper method to check for invalid time range.
   *
   * @return boolean
   */
  private boolean invalidTimeInterval() {
    if (this.timeInterval.getStartTime() < this.shape.getTimeInterval().getStartTime()) {
      return true;
    } else {
      return this.timeInterval.getEndTime() > this.shape.getTimeInterval().getEndTime();
    }
  }

  /**
   * Getter method: Operation enum type.
   *
   * @return OperationType enum
   */
  @Override
  public OperationType getOperationType() {
    return this.operationType;
  }

  /**
   * Getter method: Shape object.
   *
   * @return shape object
   */
  @Override
  public IShape getShape() {
    return this.shape;
  }

  /**
   * Getter method: timeInterval object.
   *
   * @return timeInterval object
   */
  @Override
  public TimeInterval getTimeInterval() {
    return this.timeInterval;
  }
}
