package cs5004.animator.animatorOperations;

import java.util.Objects;

import cs5004.animator.shapes.IShape;
import cs5004.animator.util.Point2D;
import cs5004.animator.util.TimeInterval;

/** A class that moves a Shape object. */
public class Move extends AbstractAnimatorOperation {
  private final Point2D newPoint2D;

  /**
   * Constructor method.
   *
   * @param newPoint2D (x, y) coordinates of shape
   * @param shape Shape object
   * @param timeInterval time elapsed
   */
  public Move(Point2D newPoint2D, IShape shape, TimeInterval timeInterval) {
    super(OperationType.MOVE, shape, timeInterval);
    this.newPoint2D = Objects.requireNonNull(newPoint2D, "Point2D object is null");
  }

  /**
   * String representation of the Move operation.
   *
   * @return string representation of the Move operation.
   */
  @Override
  public String toString() {
    return "Shape "
        + this.getShape().getName()
        + " moves from "
        + this.getShape().getPoint2D().toString()
        + " to "
        + this.newPoint2D.toString()
        + " "
        + this.getTimeInterval().toStringAnimation();
  }
}
