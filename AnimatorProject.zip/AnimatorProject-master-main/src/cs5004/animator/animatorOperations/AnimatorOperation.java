package cs5004.animator.animatorOperations;

import cs5004.animator.shapes.IShape;
import cs5004.animator.util.TimeInterval;

/** An interface for animation operations/actions. */
public interface AnimatorOperation {

  /**
   * Getter method: Operation enum type.
   *
   * @return OperationType enum
   */
  OperationType getOperationType();

  /**
   * Getter method: Shape object.
   *
   * @return shape object
   */
  IShape getShape();

  /**
   * Getter method: timeInterval object.
   *
   * @return timeInterval object
   */
  TimeInterval getTimeInterval();

  /**
   * String representation of AnimatorOperation.
   *
   * @return string representation of AnimatorOperation.
   */
  @Override
  String toString();
}
