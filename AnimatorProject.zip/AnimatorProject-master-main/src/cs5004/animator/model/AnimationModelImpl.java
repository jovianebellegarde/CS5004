package cs5004.animator.model;

import java.awt.Color;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import cs5004.animator.util.AnimationBuilder;
import cs5004.animator.shapes.Ellipse;
import cs5004.animator.shapes.IShape;
import cs5004.animator.util.Point2D;
import cs5004.animator.shapes.Rectangle;
import cs5004.animator.util.Screen;
import cs5004.animator.shapes.ShapeType;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;
import cs5004.animator.animatorOperations.AnimatorOperation;
import cs5004.animator.animatorOperations.Move;
import cs5004.animator.animatorOperations.Paint;
import cs5004.animator.animatorOperations.Scale;

/** This class represents model implementation in the Easy Animator app. */
public class AnimationModelImpl implements IAnimationModel {

  private final List<AnimatorOperation> animatorOperationsList;
  private final Map<String, IShape> shapesMap;
  private Screen screen;

  /** Constructor method for Model (MVC). */
  public AnimationModelImpl() {
    this.animatorOperationsList = new LinkedList<>();
    this.shapesMap = new LinkedHashMap<>();
    this.screen = new Screen(0, 0, 100, 100);
  }

  /**
   * Getter method: returns a shapesMap.
   *
   * @return mapping of shape's name to its own Shape object
   */
  @Override
  public Map<String, IShape> getShapesMap() {
    return this.shapesMap;
  }

  /**
   * Getter method: returns a list of AnimationOperation objects.
   *
   * @return list of AnimationOperation objects
   */
  @Override
  public List<AnimatorOperation> getTransformationList() {
    return this.animatorOperationsList;
  }

  /**
   * This method adds a Shape object to the shapesMap.
   *
   * @param shape shape object
   */
  @Override
  public void addShape(IShape shape) {
    if (shape == null || shape.getName().equals("")) {
      throw new IllegalArgumentException("Invalid identifier/Shape object is null");
    }
    this.shapesMap.put(shape.getName(), shape);
  }

  /**
   * This method removes a Shape object from shapesMap.
   *
   * @param identifier shape identifier
   */
  @Override
  public void removeShape(String identifier) {
    if (shapesMap.containsKey(identifier)) {
      this.shapesMap.remove(identifier);
    } else {
      throw new IllegalArgumentException("Invalid identifier");
    }
  }

  /**
   * Getter method: list of shapes at a specified time.
   *
   * @param time specified time
   * @return new shapesMap HashMap
   */
  @Override
  public Map<String, IShape> getShapesAtTime(int time) {
    Map<String, IShape> newShapesMap = new HashMap<>();

    for (Map.Entry<String, IShape> entry : this.shapesMap.entrySet()) {
      if (entry.getValue().getTimeInterval().getStartTime() <= time
          && entry.getValue().getTimeInterval().getEndTime() >= time) {
        newShapesMap.put(entry.getKey(), entry.getValue());
      }
    }
    return newShapesMap;
  }

  /**
   * Getter method: Screen.
   *
   * @return Screen
   */
  @Override
  public Screen getScreen() {
    return this.screen;
  }

  /**
   * This method adds animation operations to a valid Shape identifier.
   *
   * @param animationOperation animation associated with Shape object
   * @throws IllegalArgumentException if AnimationOperation is null or if there is an invalid time
   *     overlap.
   */
  @Override
  public void addAnimation(AnimatorOperation animationOperation) throws IllegalArgumentException {
    //    try {
    //      if (invalidTimeOverlap(animationOperation)) {
    //        throw new IllegalArgumentException(
    //            "AnimatorOperation has an overlapping TimeInterval with another
    // AnimatorOperation");
    //      }
    this.animatorOperationsList.add(animationOperation);
    //    } catch (NullPointerException e) {
    //      throw new IllegalArgumentException("Null animationOperation");
    //    }
  }

  //  /**
  //   * Helper method to validate time interval times for animation operations.
  //   *
  //   * @return boolean
  //   */
  //  private boolean invalidTimeOverlap(AnimatorOperation animatorOperation) {
  //    if (this.animatorOperationsList.isEmpty()) {
  //      return false;
  //    }
  //    this.animatorOperationsList.add(animatorOperation);
  //    // Current AnimatorOperation endTime must be less than the next AnimatorOperation's
  // startTime
  //    for (int i = 0; i < this.animatorOperationsList.size(); i++) {
  //      if (this.animatorOperationsList.get(i).getTimeInterval().getEndTime()
  //          < this.animatorOperationsList.get(i + 1).getTimeInterval().getStartTime()) {
  //        this.animatorOperationsList.remove(animatorOperation);
  //        return false;
  //      }
  //    }
  //    this.animatorOperationsList.remove(animatorOperation);
  //    return true;
  //  }

  /**
   * String representation of Animator Model.
   *
   * @return string representation of Animator Model
   */
  @Override
  public String toString() {
    StringBuilder stringBuilderShapes = new StringBuilder();
    StringBuilder stringBuilderAnimationOperations = new StringBuilder();

    for (Map.Entry<String, IShape> entry : this.shapesMap.entrySet()) {
      stringBuilderShapes.append(entry.getValue()).append("\n");
    }
    for (AnimatorOperation operation : this.animatorOperationsList) {
      stringBuilderAnimationOperations.append(operation.toString()).append("\n\n");
    }
    return "Shapes:\n" + stringBuilderShapes + stringBuilderAnimationOperations;
  }

  /** Animation Builder class. */
  public static final class Builder implements AnimationBuilder<IAnimationModel> {
    private final AnimationModelImpl model;
    private final Map<String, String> declaredShapesMapBuilder;

    /** Constructor method. */
    public Builder() {
      this.model = new AnimationModelImpl();
      this.declaredShapesMapBuilder = new LinkedHashMap<>();
    }

    /**
     * Constructs a final document.
     *
     * @return the newly constructed document
     */
    @Override
    public IAnimationModel build() {
      return this.model;
    }

    /**
     * Specify the bounding box to be used for the animation.
     *
     * @param x The leftmost x value
     * @param y The topmost y value
     * @param width The width of the bounding box
     * @param height The height of the bounding box
     * @return This {@link AnimationBuilder}
     */
    @Override
    public AnimationBuilder<IAnimationModel> setBounds(int x, int y, int width, int height) {
      this.model.screen = new Screen(x, y, width, height);
      return this;
    }

    /**
     * Adds a new shape to the growing document.
     *
     * @param name The unique name of the shape to be added. No shape with this name should already
     *     exist.
     * @param type The type of shape (e.g. "ellipse", "rectangle") to be added. The set of supported
     *     shapes is unspecified, but should include "ellipse" and "rectangle" as a minimum.
     * @return This {@link AnimationBuilder}
     */
    @Override
    public AnimationBuilder<IAnimationModel> declareShape(String name, String type) {
      Objects.requireNonNull(name, "Can't have a null name.");
      Objects.requireNonNull(type, "Can't have a null type");
      if (this.declaredShapesMapBuilder.containsKey(name)) {
        throw new IllegalArgumentException("Already added shape with same name.");
      }
      if ("ellipse".equals(type) || "rectangle".equals(type)) {
        this.declaredShapesMapBuilder.put(name, type);
      } else {
        throw new IllegalArgumentException("Shape type doesn't exist.");
      }
      return this;
    }

    /**
     * Adds a transformation to the growing document.
     *
     * @param name The name of the shape (added with {@link AnimationBuilder#declareShape})
     * @param t1 The start time of this transformation
     * @param x1 The initial x-position of the shape
     * @param y1 The initial y-position of the shape
     * @param w1 The initial width of the shape
     * @param h1 The initial height of the shape
     * @param r1 The initial red color-value of the shape
     * @param g1 The initial green color-value of the shape
     * @param b1 The initial blue color-value of the shape
     * @param t2 The end time of this transformation
     * @param x2 The final x-position of the shape
     * @param y2 The final y-position of the shape
     * @param w2 The final width of the shape
     * @param h2 The final height of the shape
     * @param r2 The final red color-value of the shape
     * @param g2 The final green color-value of the shape
     * @param b2 The final blue color-value of the shape
     * @return This {@link AnimationBuilder}
     */
    @Override
    public AnimationBuilder<IAnimationModel> addMotion(
        String name,
        int t1,
        int x1,
        int y1,
        int w1,
        int h1,
        int r1,
        int g1,
        int b1,
        int t2,
        int x2,
        int y2,
        int w2,
        int h2,
        int r2,
        int g2,
        int b2)
        throws IllegalArgumentException {

      Objects.requireNonNull(name, "Can't have a null name");

      switch (this.declaredShapesMapBuilder.get(name)) {
        case "ellipse":
          this.model.addShape(
              new Ellipse(
                  name,
                  new Point2D(x1, y1),
                  new Size(w1, h1),
                  new Color(r1, g1, b1),
                  new TimeInterval(t1, t2)));
          break;
        case "rectangle":
          this.model.addShape(
              new Rectangle(
                  name,
                  new Point2D(x1, y1),
                  new Size(w1, h1),
                  new Color(r1, g1, b1),
                  new TimeInterval(t1, t2)));
          break;
        default:
          throw new IllegalArgumentException("Shape not defined");
      }

      IShape abstractShape;

      if (x1 != x2 || y1 != y2) {
        abstractShape = makeAbstractShape(name, x1, y1, w1, h1, r1, g1, b1, t1, t2);
        this.model.addAnimation(
            new Move(new Point2D(x2, y2), abstractShape, new TimeInterval(t1, t2)));
      }

      if (r1 != r2 || g1 != g2 || b1 != b2) {
        abstractShape = makeAbstractShape(name, x2, y2, w1, h1, r2, g2, b2, t1, t2);
        this.model.addAnimation(
            new Paint(new Color(r2, g2, b2), abstractShape, new TimeInterval(t1, t2)));
      }

      if (w1 != w2 || h1 != h2) {
        abstractShape = makeAbstractShape(name, x2, y2, w1, h1, r2, g2, b2, t1, t2);
        this.model.addAnimation(
            new Scale(new Size(w2, h2), abstractShape, new TimeInterval(t1, t2)));
      }

      return this;
    }

    /**
     * Determines if shape is rectangle or oval depending on the type.
     *
     * @return a shape rectangle or oval.
     */
    private IShape makeAbstractShape(
        String name, int x, int y, int w, int h, int r, int g, int b, int t1, int t2) {
      Objects.requireNonNull(name, "Can't have a null name");
      IShape abstractShape;
      if (this.declaredShapesMapBuilder.get(name).equals(ShapeType.RECTANGLE.getStringShape())) {
        abstractShape =
            new Rectangle(
                name,
                new Point2D(x, y),
                new Size(w, h),
                new Color(r, g, b),
                new TimeInterval(t1, t2));
      } else {
        abstractShape =
            new Ellipse(
                name,
                new Point2D(x, y),
                new Size(w, h),
                new Color(r, g, b),
                new TimeInterval(t1, t2));
      }
      return abstractShape;
    }
  }
}
