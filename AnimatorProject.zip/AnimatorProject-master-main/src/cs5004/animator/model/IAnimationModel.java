package cs5004.animator.model;

import java.util.List;
import java.util.Map;

import cs5004.animator.shapes.IShape;
import cs5004.animator.util.Screen;
import cs5004.animator.animatorOperations.AnimatorOperation;

/** This interface represents the model (MVC) of the Animator application. */
public interface IAnimationModel {

  /**
   * Getter method: returns a shapesMap.
   *
   * @return mapping of shape's name to its own Shape object
   */
  Map<String, IShape> getShapesMap();

  /**
   * Getter method: returns a list of AnimationOperation objects.
   *
   * @return list of AnimationOperation objects
   */
  List<AnimatorOperation> getTransformationList();

  /**
   * Getter method: Screen.
   *
   * @return Screen
   */
  Screen getScreen();

  /**
   * This method adds a Shape object to the shapesMap.
   *
   * @param shape shape object
   */
  void addShape(IShape shape);

  /**
   * This method removes a Shape object from shapesMap.
   *
   * @param identifier shape identifier
   */
  void removeShape(String identifier);

  /**
   * Getter method: list of shapes at a specified time.
   *
   * @param time specified time
   * @return new shapesMap HashMap
   */
  Map<String, IShape> getShapesAtTime(int time);

  /**
   * This method adds animation operations to a valid Shape identifier.
   *
   * @param animationOperation animation associated with Shape object
   * @throws IllegalArgumentException if AnimationOperation is null
   */
  void addAnimation(AnimatorOperation animationOperation) throws IllegalArgumentException;

  /**
   * String representation of AnimationModel.
   *
   * @return String representation of AnimationModel
   */
  String toString();
}
