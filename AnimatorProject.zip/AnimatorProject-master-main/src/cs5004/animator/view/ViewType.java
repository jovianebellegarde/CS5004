package cs5004.animator.view;

// Keith Feedback: Not good OO design
// "Consider that each view type knows what it is already, and knows what messages it responds to."
/** An enum class for View types. */
public enum ViewType {
  TEXT("text"),
  SVG("svg"),
  GUI("visual");

  String viewString;

  /**
   * Constructor method.
   *
   * @param viewString string representation of ViewType
   */
  ViewType(String viewString) {
    this.viewString = viewString;
  }

  /**
   * String of ViewType.
   *
   * @return string representation of ViewType
   */
  public String getViewString() {
    return this.viewString;
  }
}
