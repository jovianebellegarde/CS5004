package cs5004.animator.view;

import java.awt.Color;
import java.awt.Dimension;
import java.util.List;
import java.util.Objects;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

import cs5004.animator.animatorOperations.AnimatorOperation;
import cs5004.animator.model.IAnimationModel;
import cs5004.animator.util.Screen;

/** This class represents the GUI view for the Animator application. */
public class VisualView extends JFrame implements IAnimationView {
  private final int speed;
  private final ViewType viewType;
  private final AnimationPanel panel;
  private Screen screen = new Screen(0, 0, 700, 700);

  /**
   * Constructor method.
   *
   * @param speed time/tick speed
   */
  public VisualView(int speed) {
    super();
    this.speed = speed;
    this.viewType = ViewType.GUI;
    this.panel = new AnimationPanel();

    // Panel setup
    JScrollPane scrollPane = new JScrollPane(this.panel);
    setScreen(this.screen);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setTitle("Easy Animator");
    add(scrollPane);
    setVisible(true);
  }

  /**
   * This method displays the model for the Animator application. The View is responsible for three
   * types of representations: 1) Text 2) SVG 3) Visual/GUI.
   *
   * @param model IAnimationModel
   */
  @Override
  public void display(IAnimationModel model) {
    Objects.requireNonNull(model, "EasyAnimator Model is null");
    List<AnimatorOperation> animatedShapes = model.getTransformationList();
    this.panel.draw(animatedShapes);
  }

  /**
   * Getter method: speed/tempo.
   *
   * @return speed/tempo
   */
  @Override
  public int getSpeed() {
    return this.speed;
  }

  /**
   * Mutator method: sets Screen object.
   *
   * @param screen Screen object
   */
  @Override
  public void setScreen(Screen screen) {
    this.screen = screen;
    this.panel.setSize(900, 900);
    this.panel.setBounds(screen.getX(), screen.getY(), screen.getWidth(), screen.getHeight());
    this.panel.setPreferredSize(new Dimension(this.screen.getWidth(), this.screen.getHeight()));
    this.panel.setBackground(Color.white);
  }

  /**
   * Getter method: get text data.
   *
   * @return string of text
   */
  @Override
  public String getText() {
    return null;
  }

  /**
   * Getter method: get ViewType.
   *
   * @return ViewType enum
   */
  @Override
  public ViewType getViewType() {
    return this.viewType;
  }

  @Override
  public void setListener(IViewControls controls) {

  }
}
