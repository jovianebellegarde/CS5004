package cs5004.animator.view;

import java.util.List;
import java.util.Objects;

import cs5004.animator.animatorOperations.AnimatorOperation;
import cs5004.animator.model.IAnimationModel;
import cs5004.animator.util.Screen;

/** This class represents the SVG view for animated Shape objects. */
public class SVGView implements IAnimationView {
  private final int speed;
  private final Screen screen;
  private final StringBuilder text;
  private final ViewType viewType;

  /**
   * Constructor method.
   *
   * @param speed speed/tempo
   * @throws IllegalArgumentException if speed is 0 or negative
   */
  public SVGView(int speed) {
    if (speed <= 0) {
      throw new IllegalArgumentException("Speed input is invalid");
    }
    this.speed = speed;
    this.screen = new Screen(0, 0, 10, 10);
    this.text = new StringBuilder();
    this.viewType = ViewType.SVG;
  }

  /**
   * This method displays the model for the Animator application. The View is responsible for three
   * types of representations: 1) Text 2) SVG 3) Visual/GUI.
   *
   * @param model IAnimationModel
   */
  @Override
  public void display(IAnimationModel model) {
    Objects.requireNonNull(model, "EasyAnimator Model is null");
    List<AnimatorOperation> animatedShapes = model.getTransformationList();

    this.text
        .append(
            String.format(
                "<svg width=\"%d\" height=\"%d\" version=\"1.1\" ",
                this.screen.getWidth(), this.screen.getHeight()))
        .append("xmlns=\"http://www.w3.org/2000/svg\">\n");
    for (AnimatorOperation operation : animatedShapes) {
      this.text.append(operation.getShape().getShapeState());
      this.text.append(operation.getShape().getShapeType().getXMLView());
    }
    // SVG ending tag
    this.text.append("</svg>");
  }

  /**
   * Getter method: speed/tempo.
   *
   * @return speed/tempo
   */
  @Override
  public int getSpeed() {
    return this.speed;
  }

  /**
   * Mutator method: sets Screen object.
   *
   * @param screen Screen object
   */
  @Override
  public void setScreen(Screen screen) {
    // Does not require
  }

  /**
   * Getter method: get text data.
   *
   * @return string of text
   */
  @Override
  public String getText() {
    return this.text.toString();
  }

  /**
   * Getter method: get ViewType.
   *
   * @return ViewType enum
   */
  @Override
  public ViewType getViewType() {
    return this.viewType;
  }

  @Override
  public void setListener(IViewControls controls) {

  }
}
