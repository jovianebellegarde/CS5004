package cs5004.animator.view;

import java.util.Objects;

import cs5004.animator.util.TimeInterval;

/** This class represents the tween method. */
public class Tween {

  /**
   * Constructor method.
   *
   * @param timeInterval TimeInterval object
   * @param currentTime current tick
   * @param startTime start
   * @param endTime end
   * @return tween value
   */
  private double tween(
          TimeInterval timeInterval, int currentTime, double startTime, double endTime) {
    Objects.requireNonNull(timeInterval);
    double tweenVal =
        (startTime
            * ((endTime - currentTime) / timeInterval.getTimeElapsed())
            * ((currentTime - timeInterval.getStartTime())
                / (double) timeInterval.getTimeElapsed()));

    return tweenVal * 1000 / (double) 1000;
  }
}
