package cs5004.animator.view;

import cs5004.animator.model.IAnimationModel;
import cs5004.animator.util.Screen;

/** This interface represents the View (MVC) in the Animator application. */
public interface IAnimationView {

  /**
   * This method displays the model for the Animator application. The View is responsible for three
   * types of representations: 1) Text 2) SVG 3) Visual/GUI.
   *
   * @param model IAnimationModel
   */
  void display(IAnimationModel model);

  /**
   * Getter method: speed/tempo.
   *
   * @return speed/tempo
   */
  int getSpeed();

  /**
   * Mutator method: sets Screen object.
   *
   * @param screen Screen object
   */
  void setScreen(Screen screen);

  /**
   * Getter method: get text data.
   *
   * @return string of text
   */
  String getText();

  /**
   * Getter method: get ViewType.
   *
   * @return ViewType enum
   */
  ViewType getViewType();

  /**
   * This method sets the listener object.
   * @param controls controls
   */
  void setListener(IViewControls controls);
}
