package cs5004.animator.view;

import javax.swing.JSlider;

import cs5004.animator.shapes.IShape;

/** This class represents all of the control operations for the Easy Animator. */
public interface IViewControls {

  /** This method represents the start button for the animator. */
  void start();

  /** This method represents the pause button for the animator. */
  void pause();

  /** This method represents the resume button for the animator. */
  void resume();

  /** This method represents the restart button for the animator. */
  void restart();

  /**
   * This method loops the animation.
   *
   * @param bool boolean
   */
  void loop(boolean bool);

  /**
   * This method adds a new shape.
   *
   * @param shape Shape
   */
  void addShape(IShape shape);

  /**
   * This method removes a shape.
   *
   * @param identifier Shape identifier/name
   */
  void removeShape(String identifier);

  /**
   * This method represents a slider, in order to manipulate the time of the animation.
   *
   * @param jSlider JSlider
   * @param number speed
   */
  void scrub(JSlider jSlider, int number);
}
