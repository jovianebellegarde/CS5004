package cs5004.animator.view;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import cs5004.animator.animatorOperations.AnimatorOperation;
import cs5004.animator.model.IAnimationModel;
import cs5004.animator.shapes.IShape;
import cs5004.animator.util.Screen;

/** This represents a textual View class of animated Shape objects. */
public class TextView implements IAnimationView {
  private final Screen screen;
  private final StringBuilder text;
  private final ViewType viewType;

  /** Constructor method. */
  public TextView() {
    this.text = new StringBuilder();
    this.viewType = ViewType.TEXT;
    this.screen = new Screen(0, 0, 10, 10);
  }

  /**
   * This method displays the model for the Animator application. The View is responsible for three
   * types of representations: 1) Text 2) SVG 3) Visual/GUI.
   *
   * @param model IAnimationModel
   */
  @Override
  public void display(IAnimationModel model) {
    Objects.requireNonNull(model, "EasyAnimator Model is null");
    List<AnimatorOperation> animatedShapes = model.getTransformationList();

    this.text.append("Canvas: ");
    this.text.append(this.screen).append("\n");

    for (Map.Entry<String, IShape> entry : model.getShapesMap().entrySet()) {
      this.text.append(entry.getValue().toString()).append("\n");
    }
    for (AnimatorOperation animatedShape : animatedShapes) {
      this.text.append(animatedShape.toString()).append("\n");
    }
  }

  /**
   * Getter method: speed/tempo.
   *
   * @return speed/tempo
   */
  @Override
  public int getSpeed() {
    return 0;
  }

  /**
   * Getter method: Screen object.
   *
   * @return Screen
   */
  public Screen getScreen() {
    return this.screen;
  }

  /**
   * Mutator method: sets Screen object.
   *
   * @param screen Screen object
   */
  @Override
  public void setScreen(Screen screen) {
    // Does not require
  }

  /**
   * Getter method: get text data.
   *
   * @return string of text
   */
  @Override
  public String getText() {
    return this.text.toString();
  }

  /**
   * Getter method: get ViewType.
   *
   * @return ViewType enum
   */
  @Override
  public ViewType getViewType() {
    return this.viewType;
  }

  /**
   * This method sets the listener object.
   * @param controls controls
   */
  @Override
  public void setListener(IViewControls controls) {

  }


}

