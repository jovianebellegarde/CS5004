package cs5004.animator.view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.List;
import java.util.Objects;
import javax.swing.JPanel;

import cs5004.animator.animatorOperations.AnimatorOperation;
import cs5004.animator.shapes.ShapeType;

/** This class represents the panel of the Animation model. */
public class AnimationPanel extends JPanel implements IAnimationPanel {
  private List<AnimatorOperation> animatedShapes;

  /** Constructor method. */
  public AnimationPanel() {
    super();
  }

  /**
   * Draws shapes of the model.
   *
   * @param g graphics
   */
  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(Objects.requireNonNull(g));
    Graphics2D graphics2D = (Graphics2D) g;

    for (AnimatorOperation operation : this.animatedShapes) {
      graphics2D.setColor(new Color(operation.getShape().getColor().getRGB()));
      if (operation.getShape().getShapeType() == ShapeType.ELLIPSE) {
        graphics2D.fillOval(
            (int) operation.getShape().getPoint2D().getX(),
            (int) operation.getShape().getPoint2D().getY(),
            (int) operation.getShape().getSize().getWidth() / 2,
            (int) operation.getShape().getSize().getHeight() / 2);
      }
      if (operation.getShape().getShapeType() == ShapeType.RECTANGLE) {
        graphics2D.fillRect(
            (int) operation.getShape().getPoint2D().getX(),
            (int) operation.getShape().getPoint2D().getY(),
            (int) operation.getShape().getSize().getWidth(),
            (int) operation.getShape().getSize().getHeight());
      }
    }
  }

  /**
   * Method that draws Shapes for JPanel.
   *
   * @param animatedShapes animatedShapes/AnimatorOperations
   */
  @Override
  public void draw(List<AnimatorOperation> animatedShapes) {
    this.animatedShapes = animatedShapes;
    repaint();
  }
}
