package cs5004.animator.view;

import cs5004.animator.animatorOperations.AnimatorOperation;
import java.util.List;

/** This interface facilitates the drawing of Shape objects for the panel. */
public interface IAnimationPanel {

  /**
   * Method that draws Shapes for JPanel.
   *
   * @param animatedShapes animatedShapes/AnimatorOperations
   */
  void draw(List<AnimatorOperation> animatedShapes);
}
