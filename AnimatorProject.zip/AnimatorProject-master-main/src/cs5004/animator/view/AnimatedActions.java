package cs5004.animator.view;

import java.awt.Color;
import java.util.Objects;

import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;

/** This class represents animated Shape objects. */
public class AnimatedActions {
  private final Point2D endPoint2D;
  private final Size endSize;
  private final Color endColor;

  /**
   * Constructor method.
   *
   * @param endPoint2D new location
   * @param endSize new size
   * @param endColor new color
   */
  public AnimatedActions(
      Point2D endPoint2D, Size endSize, Color endColor, TimeInterval timeInterval) {
    this.endPoint2D = Objects.requireNonNull(endPoint2D, "Null object");
    this.endSize = Objects.requireNonNull(endSize, "Null object");
    this.endColor = Objects.requireNonNull(endColor, "Null object");
  }

  /**
   * Getter method: new location.
   *
   * @return Point2D
   */
  public Point2D getEndPoint2D() {
    return new Point2D(this.endPoint2D);
  }

  /**
   * Getter method: new size.
   *
   * @return Size
   */
  public Size getEndSize() {
    return new Size(this.endSize);
  }

  /**
   * Getter method: new color.
   *
   * @return Color
   */
  public Color getEndColor() {
    return new Color(this.endColor.getRGB());
  }
}
