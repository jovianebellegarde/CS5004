package cs5004.animator.view;

/** Factory class for selecting viewType displays at runtime. */
public class FactoryView {
  /**
   * Factory method for viewType displays.
   *
   * @param viewType string representation of view type
   * @param speed time tempo
   * @return new View object selected
   * @throws IllegalArgumentException if ViewType does not exist
   */
  public static IAnimationView makeView(String viewType, int speed)
      throws IllegalArgumentException {
    switch (viewType) {
      case "text":
        return new TextView();
      case "svg":
        return new SVGView(speed);
      case "visual":
        return new VisualView(speed);
    }
    throw new IllegalArgumentException("ViewType does not exist");
  }
}