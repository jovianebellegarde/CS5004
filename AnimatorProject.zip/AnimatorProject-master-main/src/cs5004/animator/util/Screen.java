package cs5004.animator.util;

/** A class that represents the screen dimensions. */
public class Screen {
  private final int x;
  private final int y;
  private final int height;
  private final int width;

  /**
   * Constructor method.
   *
   * @param x x-coordinate
   * @param y y-coordinate
   * @param height height
   * @param width width
   */
  public Screen(int x, int y, int width, int height) throws IllegalArgumentException {
    if (width <= 0 || height <= 0) {
      throw new IllegalArgumentException("Invalid height/width values");
    }
    this.x = x;
    this.y = y;
    this.height = height;
    this.width = width;
  }

  /**
   * Getter method: x-coordinate.
   *
   * @return x-coordinate
   */
  public int getX() {
    return this.x;
  }

  /**
   * Getter method: y-coordinate.
   *
   * @return y-coordinate
   */
  public int getY() {
    return this.y;
  }

  /**
   * Getter method: height.
   *
   * @return height
   */
  public int getHeight() {
    return this.height;
  }

  /**
   * Getter method: width.
   *
   * @return width
   */
  public int getWidth() {
    return this.width;
  }

  @Override
  public String toString() {
    return String.format("(%d, %d) Height: %d Width %d", this.x, this.y, this.height, this.width);
  }
}
