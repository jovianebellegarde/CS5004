package cs5004.animator.util;

import java.util.Objects;

/** A class that represents sizing for a Shape object. */
public class Size {
  private double height;
  private double width;

  /**
   * Constructor method with primitives.
   *
   * @param height height
   * @param width width
   * @throws IllegalArgumentException if height or width are negative
   */
  public Size(double width, double height) throws IllegalArgumentException {
    if (height <= 0 || width <= 0) {
      throw new IllegalArgumentException("Invalid height/width values");
    }
    this.width = width;
    this.height = height;
  }

  /**
   * Constructor method with Size object.
   *
   * @param size Size
   * @throws IllegalArgumentException if height or width are negative
   */
  public Size(Size size) throws IllegalArgumentException {
    this.height = size.getHeight();
    this.width = size.getWidth();
  }

  /**
   * Getter method: height.
   *
   * @return height
   */
  public double getHeight() {
    return this.height;
  }

  /**
   * Setter method: height.
   *
   * @param height height
   */
  public void setHeight(double height) {
    this.height = height;
  }

  /**
   * Getter method: width.
   *
   * @return width
   */
  public double getWidth() {
    return this.width;
  }

  /**
   * Setter method: width.
   *
   * @param width width
   */
  public void setWidth(double width) {
    this.width = width;
  }

  /**
   * Indicates whether some other Shape is "equal to" this one.
   *
   * @return boolean
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Size)) {
      return false;
    }
    Size that = (Size) o;
    return this.height == that.height && this.width == that.width;
  }

  /**
   * Returns a hash code value for the object. This method is supported for the benefit of hash
   * tables such as those provided by HashMap.
   *
   * @return int
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.height, this.width);
  }

  /** String representation of a Size object. */
  @Override
  public String toString() {
    return "Width: " + this.width + ", Height: " + this.height;
  }
}
