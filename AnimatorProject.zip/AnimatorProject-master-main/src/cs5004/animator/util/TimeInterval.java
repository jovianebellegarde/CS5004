package cs5004.animator.util;

import java.util.Objects;

/** A class that represents how much time has elapsed (Execution time). */
public class TimeInterval {
  private final int startTime;
  private final int endTime;
  private final int timeElapsed;

  /**
   * Constructor method.
   *
   * @param startTime start
   * @param endTime end
   * @throws IllegalArgumentException if either time is less than 0 or if ending time is less than
   *     start time
   */
  public TimeInterval(int startTime, int endTime) throws IllegalArgumentException {
    if (startTime < 0 || endTime < 0 || startTime > endTime || endTime == startTime) {
      throw new IllegalArgumentException("Invalid time inputs");
    }
    this.startTime = startTime;
    this.endTime = endTime;
    this.timeElapsed = this.endTime - this.startTime;
  }

  /**
   * Getter method: start time.
   *
   * @return start time
   */
  public int getStartTime() {
    return this.startTime;
  }

  /**
   * Getter method: end time.
   *
   * @return end time
   */
  public int getEndTime() {
    return this.endTime;
  }

  /**
   * Getter method: total time elapsed.
   *
   * @return time elapsed
   */
  public int getTimeElapsed() {
    return this.timeElapsed;
  }

  /**
   * Indicates whether some other Shape is "equal to" this one.
   *
   * @return boolean
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof TimeInterval)) {
      return false;
    }
    TimeInterval that = (TimeInterval) o;
    return this.startTime == that.startTime && this.endTime == that.endTime;
  }

  /**
   * Returns a hash code value for the object. This method is supported for the benefit of hash
   * tables such as those provided by HashMap.
   *
   * @return int
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.startTime, this.endTime);
  }

  /**
   * Custom toString() method for Shape objects.
   *
   * @return timeInterval string for Shapes
   */
  public String toStringShape() {
    return String.format("Appears at t=%d\n" + "Disappears at t=%d", this.startTime, this.endTime);
  }

  /**
   * Custom toString() method for AnimatorOperations objects.
   *
   * @return timeInterval string for AnimatorOperations
   */
  public String toStringAnimation() {
    return String.format("from t=%d " + "to t=%d", this.startTime, this.endTime);
  }
}
