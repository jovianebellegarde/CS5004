package cs5004.animator.util;

import java.util.Objects;

/** A class that represents (x, y) coordinates for objects. */
public class Point2D {
  private double x;
  private double y;

  /**
   * Constructor method with primitive parameters.
   *
   * @param x x-coordinate
   * @param y y-coordinate
   */
  public Point2D(double x, double y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Constructor method with a Point2D object.
   *
   * @param point2D Point2D
   */
  public Point2D(Point2D point2D) {
    this.x = point2D.getX();
    this.y = point2D.getY();
  }

  /**
   * Getter method: x_coordinate.
   *
   * @return double value
   */
  public double getX() {
    return this.x;
  }

  /**
   * Getter method: y_coordinate.
   *
   * @return double value
   */
  public double getY() {
    return this.y;
  }

  /**
   * Indicates whether some other Shape is "equal to" this one.
   *
   * @return boolean
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Point2D)) {
      return false;
    }
    Point2D that = (Point2D) o;
    return this.x == that.x && this.y == that.y;
  }

  /**
   * Returns a hash code value for the object. This method is supported for the benefit of hash
   * tables such as those provided by HashMap.
   *
   * @return int
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.x, this.y);
  }

  /** String representation of a Point2D object. */
  @Override
  public String toString() {
    return String.format("(%.1f,%.1f)", this.x, this.y);
  }
}
