package cs5004.animator.shapes;

/** An enum class for Shape types. */
public enum ShapeType {
  RECTANGLE("rectangle"),
  ELLIPSE("ellipse");

  String shapeString;

  /**
   * Constructor method.
   *
   * @param shapeString string representation of ShapeType
   */
  ShapeType(String shapeString) {
    this.shapeString = shapeString;
  }

  /**
   * String of ShapeType.
   *
   * @return string representation of ShapeType
   */
  public String getStringShape() {
    return this.shapeString;
  }

  /**
   * XML representations of Shape.
   *
   * @return string XML representation
   */
  public String getXMLView() {
    switch (this) {
      case RECTANGLE:
        return "XML_RECTANGLE";
      case ELLIPSE:
        return "XML_ELLIPSE";
      default:
        throw new IllegalArgumentException("ShapeType does not exist");
    }
  }
}
