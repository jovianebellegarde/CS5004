package cs5004.animator.shapes;

import java.awt.Color;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import cs5004.animator.view.AnimatedActions;
import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;
import cs5004.animator.animatorOperations.AnimatorOperation;

/** An abstract class for a shape. */
public abstract class AbstractShape implements IShape {
  private final String name;
  private final ShapeType shapeType;
  private final TimeInterval timeInterval;
  private Point2D point2D;
  private Size size;
  private Color color;
  private List<AnimatorOperation> animatorOperationList;

  /**
   * Constructor method.
   *
   * @param name name of shape
   * @param shapeType ShapeType enum
   * @param point2D (x, y) coordinate (lower left) of shape
   * @param size size of shape
   * @param color RGB color of shape
   * @param timeInterval timeInterval of shape
   */
  public AbstractShape(
      String name,
      ShapeType shapeType,
      Point2D point2D,
      Size size,
      Color color,
      TimeInterval timeInterval)
      throws IllegalArgumentException {
    this.name = Objects.requireNonNull(name, "Name is null");
    this.shapeType = Objects.requireNonNull(shapeType, "ShapeType is null");
    this.point2D = Objects.requireNonNull(point2D, "Point2D is null");
    this.size = Objects.requireNonNull(size, "Size is null");
    this.color = Objects.requireNonNull(color, "Color is null");
    this.timeInterval = Objects.requireNonNull(timeInterval, "timeInterval is null");
    this.animatorOperationList = new LinkedList<>();
  }

  /**
   * Getter method: Shape name.
   *
   * @return string name for a Shape object
   */
  public String getName() {
    return this.name;
  }

  /**
   * Getter method: Shape type.
   *
   * @return ShapeType enum
   */
  public ShapeType getShapeType() {
    return this.shapeType;
  }

  /**
   * Getter method: (x, y) point of Shape.
   *
   * @return lower left Point object
   */
  @Override
  public Point2D getPoint2D() {
    return this.point2D;
  }

  /**
   * Getter method: height and width of Shape.
   *
   * @return Size object
   */
  @Override
  public Size getSize() {
    return this.size;
  }

  /**
   * Getter method: RGB color decimal values.
   *
   * @return color object
   */
  @Override
  public Color getColor() {
    return this.color;
  }

  /**
   * Getter method: timeInterval object.
   *
   * @return timeInterval object
   */
  @Override
  public TimeInterval getTimeInterval() {
    return this.timeInterval;
  }

  /**
   * Returns the string representation of the XML/SVG format for the specified shape.
   *
   * @param speed tempo/speed
   * @param animatedActions animated Shapes
   * @return XML format for SVG
   */
  @Override
  public abstract String convertToXML(int speed, AnimatedActions animatedActions);

  /**
   * Returns state changes of this Shape.
   *
   * @return animationOperations performed on this Shape
   */
  @Override
  public String getShapeState() {
    return this.animatorOperationList.stream()
        .map(operation -> operation.getOperationType().toString() + "\n")
        .collect(Collectors.joining());
  }

  /**
   * Getter method: Retrieve list of animatorOperations on this Shape.
   *
   * @return list of animatorOperations
   */
  @Override
  public List<AnimatorOperation> getAnimatorOperationList() {
    return this.animatorOperationList;
  }

  /**
   * Custom clone() method.
   *
   * @return AbstractShape type
   */
  @Override
  public abstract AbstractShape copy();

  /**
   * Indicates whether some other Shape is "equal to" this one.
   *
   * @return boolean
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof AbstractShape)) {
      return false;
    }
    AbstractShape that = (AbstractShape) o;
    return Objects.equals(this.color, that.color)
        && Objects.equals(this.point2D, that.point2D)
        && this.shapeType == that.shapeType;
  }

  /**
   * Returns a hash code value for the object. This method is supported for the benefit of hash
   * tables such as those provided by HashMap.
   *
   * @return int
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.color, this.point2D, this.shapeType);
  }
}
