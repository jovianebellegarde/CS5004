package cs5004.animator.shapes;

import java.awt.Color;

import cs5004.animator.view.AnimatedActions;
import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;

/** A class that represents a Rectangle object. */
public class Rectangle extends AbstractShape {

  /**
   * Constructor method.
   *
   * @param name name of Rectangle
   * @param point2D (x, y) coordinate (lower left) of Rectangle
   * @param size size of Rectangle
   * @param color RGB colors of Rectangle
   * @param timeInterval timeInterval object
   */
  public Rectangle(
          String name, Point2D point2D, Size size, Color color, TimeInterval timeInterval) {
    super(name, ShapeType.RECTANGLE, point2D, size, color, timeInterval);
  }

  /**
   * Returns the string representation of the SVG format for the specified shape.
   *
   * @param speed tempo/speed
   * @param animatedActions animated Shapes
   * @return SVG string
   */
  @Override
  public String convertToXML(int speed, AnimatedActions animatedActions) {

    return animateTagHelper(
        "x",
        this.getTimeInterval(),
        Double.toString(this.getPoint2D().getX()),
        Double.toString(animatedActions.getEndPoint2D().getX()))
        + animateTagHelper(
        "y",
        this.getTimeInterval(),
        Double.toString(this.getPoint2D().getY()),
        Double.toString(animatedActions.getEndPoint2D().getY()))
        + animateTagHelper(
        "width",
        this.getTimeInterval(),
        Double.toString(this.getSize().getWidth()),
        Double.toString(animatedActions.getEndSize().getWidth()))
        + animateTagHelper(
        "height",
        this.getTimeInterval(),
        Double.toString(this.getSize().getHeight()),
        Double.toString(animatedActions.getEndSize().getHeight()))
        + animateTagHelper(
        "fill",
        this.getTimeInterval(),
        "rgb("
            + this.getColor().getRed()
            + ", "
            + this.getColor().getGreen()
            + ", "
            + this.getColor().getBlue()
            + ")",
        "rgb("
            + animatedActions.getEndColor().getRed()
            + ", "
            + animatedActions.getEndColor().getGreen()
            + ", "
            + animatedActions.getEndColor().getBlue()
            + ")");
  }

  /**
   * XML formatter helper method.
   *
   * @param label label type
   * @param timeInterval TimeInterval
   * @param preAnimation before animation state
   * @param postAnimation after animation state
   * @return XML formatted string
   */
  private String animateTagHelper(
      String label, TimeInterval timeInterval, String preAnimation, String postAnimation) {
    return "\t<animate "
        + "attributeName=\""
        + label
        + "\" "
        + "attributeType=\"XML\" "
        + "begin=\""
        + timeInterval.getStartTime()
        + "ms\" "
        + "dur=\""
        + timeInterval.getTimeElapsed()
        + "ms\" "
        + "fill=\"freeze\" "
        + "from=\""
        + preAnimation
        + "\" "
        + "to=\""
        + postAnimation
        + "\"/>\n";
  }

  /**
   * Custom clone() method.
   *
   * @return AbstractShape type
   */
  @Override
  public AbstractShape copy() {
    return new Rectangle(
        this.getName(), this.getPoint2D(), this.getSize(), this.getColor(), this.getTimeInterval());
  }

  /**
   * String representation of Shape.
   *
   * @return string representation of Shape
   */
  @Override
  public String toString() {
    return String.format(
        "Name: %s\n"
            + "Type: %s\n"
            + "Min corner: (%.1f,%.1f), Width: %.1f, Height: %.1f, "
            + "Color: (%d,%d,%d)\n"
            + "%s\n",
        this.getName(),
        this.getShapeType().getStringShape(),
        this.getPoint2D().getX(),
        this.getPoint2D().getY(),
        this.getSize().getWidth(),
        this.getSize().getHeight(),
        this.getColor().getRed(),
        this.getColor().getGreen(),
        this.getColor().getBlue(),
        this.getTimeInterval().toStringShape());
  }
}
