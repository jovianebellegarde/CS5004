package cs5004.animator.shapes;

import java.awt.Color;
import java.util.List;

import cs5004.animator.view.AnimatedActions;
import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;
import cs5004.animator.animatorOperations.AnimatorOperation;

/** This interface represents a read-only interface to ensure these methods are not mutated. */
public interface IShape {

  /**
   * Getter method: Shape name.
   *
   * @return string name for a Shape object
   */
  String getName();

  /**
   * Getter method: Shape type.
   *
   * @return ShapeType enum
   */
  ShapeType getShapeType();

  /**
   * Getter method: (x, y) point of Shape.
   *
   * @return lower left Point object
   */
  Point2D getPoint2D();

  /**
   * Getter method: height and width of Shape.
   *
   * @return Size object
   */
  Size getSize();

  /**
   * Getter method: RGB color decimal values.
   *
   * @return Colors object
   */
  Color getColor();

  /**
   * Getter method: timeInterval object.
   *
   * @return timeInterval object
   */
  TimeInterval getTimeInterval();

  /**
   * Returns the string representation of the XML/SVG format for the specified shape.
   *
   * @param speed tempo/speed
   * @param animatedActions animated Shapes
   * @return XML format for SVG
   */
  String convertToXML(int speed, AnimatedActions animatedActions);

  /**
   * Returns state changes of this Shape.
   *
   * @return animationOperations performed on this Shape
   */
  String getShapeState();

  /**
   * Getter method: Retrieve list of animatorOperations on this Shape.
   *
   * @return list of animatorOperations
   */
  List<AnimatorOperation> getAnimatorOperationList();

  /**
   * Custom clone() method.
   *
   * @return AbstractShape type
   */
  AbstractShape copy();

  /**
   * String representation of Shape.
   *
   * @return string representation of Shape.
   */
  @Override
  String toString();
}
