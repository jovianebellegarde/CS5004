# Easy Animator
## CS 5004 (Spring 2021): Complete MVC - Easy Animator

**Easy Animator** is a an application that helps to create simple 2D animations from Shapes. The goals of this project include:
>
* Build a GUI using Java Swing
* Show mastery of the fundamentals of object-oriented design (SOLID, Inheritance, Encapsulation, Polymorphism, and Abstraction)
* Confidence with Model-View-Controller architecture


### Background
"A picture is worth a thousand words". Sometimes explaining an idea is easier with a picture. This application gives users an easy way to create static or dynamic animations using a simple GUI or text without having to learn complicated tools or learning another programming language.

### Model
Our group wanted to abstract as much as possible in order to decouple as many component from each other as possible. In order to achieve that, we developed a utilities directory where we abstracted components such as sizing or (x, y) positions into their own classes, examples include: 
* `Point2D`
* `TimeInterval`
* `Size`
* `Screen`

Ultimately, the util folder represents an *Aggregation* for our `AbstractShape` and `AnimatorOperation` objects.
For IShape and AnimatorOperation objects, we created one enumeration and one abstract class each to ensure type safety and for future extensions.  

**_Technical summary for `IShape`:_**
>
1. Enforce strict typing of ShapeTypes with an enumeration class.
2. `AbstractShape` implements the `IShape` interface. 
3. Various `IShape` types will extend the abstract class which facilitates the quick addition of adding more `ShapeType`'s.
>
<img align="center" src="https://user-images.githubusercontent.com/39100176/115157234-073fc100-a03d-11eb-9750-bd758fcb77ce.png"><br/>
<sub>IShape UML</sub>
>
>
**_Technical summary for `AnimatorOperation`:_**

1. Enforce strict typing of OperationTypes with an enumeration class.
2. `AbstractAnimatorOperation` implements the `AnimatorOperation` interface. 
3. Various animator operation types will extend the abstract class which facilitates the quick addition of adding more `OperationType`'s.
>
<img align="center" src="https://user-images.githubusercontent.com/39100176/115157245-19b9fa80-a03d-11eb-82e1-759f50327d81.png"><br/>
<sub>AnimatorOperation UML</sub>
>
>
**_`IAnimationModel` & `AnimationModelImplementation`_**
>
Fields:
1. An ArrayList of `AnimationOperation`s which represents a list of `IShape` transformations. Each `ShapeType` has the following attributes:
* Name
* `ShapeType`
* `TimeInterval`
* `Point2D`
* `Size`
* `java.awt.Color`
>
Justifications: Every IShape object has a unique identifier/name and data essential for animations to run are tied to these objects.

2. A HashMap of <shapeName, `IShape` type>
* `OperationType`
* `IShape` (Shape object attributes above)
* `TimeInterval`
>
Justifications: Every AnimationOperation object is coupled with its respective Shape and time is synced within the Shapes's TimeInterval.

3. `Screen` object from the utilities folder to set the screen size for the GUI.

## View

An `AnimationBuilder` and `AnimationReader` classes were provided as starter files in order to parse through input files. `IViewAnimation` is an interface for the three separate views that require implementing:
* TextView (Strings)
* SVGView (SVG)
* VisualView (GUI using Java Swing)
>
These three classes above implement `IViewAnimation`, as well as `AnimationPanel`. `AnimationPanel` faciliatates the GUI built for the `VisualView` class.

## Controller
* `EasyAnimator`: The main served as the entry point to take in the user arguments for our program.
* The user arguments were provided to the `AnimationControllerImpl`, through the applicable view and model structures.
* To align with the traditional MVC structure, our approach was to use our  `AnimationControllerImpl` as the glue of the program. 
* Justifications: By taking this approach, we designated our Controller to execute the flow of the program, and were able to link our view and model methods.
* Once the Controller was given the model and view, it served as a delegator to assign responsiblities based on the user's input from the command line and execute the program.


