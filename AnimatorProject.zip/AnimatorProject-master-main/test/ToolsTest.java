import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

import cs5004.animator.util.Screen;
import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;
import java.util.Random;
import org.junit.Test;

/** JUnit test for developerTools. */
public class ToolsTest {
  Point2D point2D;
  Screen screen;
  Size size;
  TimeInterval timeInterval;

  /** Testing Point2D constructor via fuzzy testing. */
  @Test
  public void testPoint2DConstructor() {
    // Check zeros
    this.point2D = new Point2D(0, 0);
    assertEquals((String.format("(%.1f,%.1f)", 0.0, 0.0)), this.point2D.toString());

    // Check positives
    for (int i = 0; i < 1000; i++) {
      Random r = new Random();
      double x_coord = r.nextDouble() + r.nextInt(5000);
      double y_coord = r.nextDouble() + r.nextInt(5000);
      this.point2D = new Point2D(x_coord, y_coord);
      assertEquals((String.format("(%.1f,%.1f)", x_coord, y_coord)), this.point2D.toString());
    }

    // Check negatives
    for (int i = 0; i < 1000; i++) {
      Random r = new Random();
      double x_coord = r.nextDouble() + r.nextInt(5000);
      double y_coord = r.nextDouble() + r.nextInt(5000);
      this.point2D = new Point2D(-x_coord, -y_coord);
      assertEquals((String.format("(%.1f,%.1f)", -x_coord, -y_coord)), this.point2D.toString());
    }
  }

  /** Testing Screen constructor via fuzzy testing. */
  @Test(expected = IllegalArgumentException.class)
  public void testScreenConstructor() {
    // Check zeros
    this.screen = new Screen(0, 0, 0, 0);
    assertEquals(
        "(" + 0 + ", " + 0 + ") " + "Height: " + 0 + " Width: " + 0, this.screen
            .toString());

    // Check positives
    for (int i = 0; i < 1000; i++) {
      Random r = new Random();
      // Add 1 to avoid zero
      int x_coord = r.nextInt(5000) + 1;
      int y_coord = r.nextInt(5000) + 1;
      int height = r.nextInt(5000) + 1;
      int width = r.nextInt(5000) + 1;
      this.screen = new Screen(x_coord, y_coord, width, height);
      assertEquals(
          "(" + x_coord + ", " + y_coord + ") " + "Height: " + height + " Width: " + width,
          this.screen.toString());
    }

    // Check negatives
    for (int i = 0; i < 1000; i++) {
      Random r = new Random();
      // Add 1 to avoid zero
      int x_coord = r.nextInt(5000) + 1;
      int y_coord = r.nextInt(5000) + 1;
      int height = r.nextInt(5000) + 1;
      int width = r.nextInt(5000) + 1;
      this.screen = new Screen(-x_coord, -y_coord, -height, -width);
      assertEquals(
          "(" + -x_coord + ", " + -y_coord + ") " + "Height: " + -height + " Width: " + -width,
          this.screen.toString());
    }
  }

  /** Testing Size constructor via fuzzy testing. */
  @Test
  public void testSizeConstructor() {
    for (int i = 0; i < 1000; i++) {
      Random r = new Random();
      // Add 1 to avoid zero
      double height = r.nextInt(5000) + r.nextDouble() + 1;
      double width = r.nextInt(5000) + r.nextDouble() + 1;
      this.size = new Size(width, height);
      assertEquals("Width: " + width + ", Height: " + height, this.size.toString());
    }
  }

  /** Testing TimeInterval constructor via fuzzy testing. */
  @Test
  public void testTimeIntervalConstructor() {
    for (int i = 0; i < 1000; i++) {
      Random r = new Random();
      // Add 1 to avoid zero
      int startTime = r.nextInt(5000) + 1;
      int endTime = r.nextInt(5000) + 1;
      if (startTime < endTime) {
        this.timeInterval = new TimeInterval(startTime, endTime);
        assertEquals(
            String.format("from t=%d to t=%d", startTime, endTime),
            this.timeInterval.toStringAnimation());
      }
    }
  }

  /** Testing invalid inputs for Size constructor. */
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidSizeConstructor() {
    Random r = new Random();
    double negative1 = r.nextInt(5000) + r.nextDouble() + 1;
    double negative2 = r.nextInt(5000) + r.nextDouble() + 1;
    this.size = new Size(-negative1, -negative2);
  }

  /** Testing invalid inputs for TimeInterval constructor. */
  @Test(expected = IllegalArgumentException.class)
  public void testNegativeTimeConstructor() {
    Random r = new Random();
    int negative1 = r.nextInt(5000) + 1;
    int negative2 = r.nextInt(5000) + 1;

    this.timeInterval = new TimeInterval(negative1, -negative2);
    this.timeInterval = new TimeInterval(-negative1, negative2);
    this.timeInterval = new TimeInterval(-negative1, -negative2);
  }

  /** Testing invalid inputs for TimeInterval constructor. */
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidTimeConstructor() {
    this.timeInterval = new TimeInterval(0, 0);
    this.timeInterval = new TimeInterval(10, 10);
  }

  /** Testing invalid inputs for TimeInterval constructor. */
  @Test(expected = IllegalArgumentException.class)
  public void testInvalidStartTime() {
    Random r = new Random();
    int startTime = r.nextInt(5000) + 1;
    int endTime = r.nextInt(5000) + 1;
    if (startTime > endTime) {
      this.timeInterval = new TimeInterval(startTime, endTime);
    }
  }

  /** Test getter methods. */
  @Test
  public void testGetterMethods() {
    this.point2D = new Point2D(-4, 5);
    this.screen = new Screen(2, -7, 40, 45);
    this.size = new Size(5, 5);
    this.timeInterval = new TimeInterval(4, 100);

    // Point2D
    assertEquals(-4, this.point2D.getX(), 0.001);
    assertEquals(5, this.point2D.getY(), 0.001);

    // Screen
    assertEquals(2, this.screen.getX());
    assertEquals(-7, this.screen.getY());
    assertEquals(40, this.screen.getHeight());
    assertEquals(45, this.screen.getWidth());

    // Size
    assertEquals(5, this.size.getHeight(), 0.001);
    assertEquals(5, this.size.getWidth(), 0.001);

    // TimeInterval
    assertEquals(4, this.timeInterval.getStartTime());
    assertEquals(100, this.timeInterval.getEndTime());
    assertEquals(96, this.timeInterval.getTimeElapsed());
  }

  /** Test setter methods. */
  @Test
  public void testMutatorMethods() {
    this.point2D = new Point2D(-4, 5);
    this.screen = new Screen(2, -7, 40, 45);
    this.size = new Size(5, 5);
    this.timeInterval = new TimeInterval(4, 100);

    // Point2D getters
    assertEquals(-6, this.point2D.getX(), 0.001);
    assertEquals(20, this.point2D.getY(), 0.001);

    // Size setters
    this.size.setHeight(40);
    this.size.setWidth(90);

    // Size getters
    assertEquals(40, this.size.getHeight(), 0.001);
    assertEquals(90, this.size.getWidth(), 0.001);
  }

  /** Test for equality. */
  @Test
  public void testEquals() {
    this.point2D = new Point2D(-4, 5);
    this.screen = new Screen(2, -7, 40, 45);
    this.size = new Size(5, 5);
    this.timeInterval = new TimeInterval(4, 100);

    // Equality preserved
    assertEquals(this.timeInterval, new TimeInterval(4, 100));
    assertEquals(this.point2D, new Point2D(-4, 5));
    assertEquals(this.size, new Size(5, 5));

    // Memory addresses should all be different
    assertNotSame(this.timeInterval, new TimeInterval(4, 100));
    assertNotSame(this.point2D, new Point2D(-4, 5));
    assertNotSame(this.size, new Size(5, 5));
    assertNotSame(this.screen, new Screen(2, -7, 40, 45));
  }
}
