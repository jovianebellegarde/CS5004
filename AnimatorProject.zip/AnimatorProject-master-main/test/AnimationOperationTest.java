import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import cs5004.animator.animatorOperations.AnimatorOperation;
import cs5004.animator.animatorOperations.Move;
import cs5004.animator.animatorOperations.OperationType;
import cs5004.animator.animatorOperations.Paint;
import cs5004.animator.animatorOperations.Scale;
import cs5004.animator.util.Screen;
import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;
import cs5004.animator.shapes.IShape;
import cs5004.animator.shapes.Ellipse;
import cs5004.animator.shapes.Rectangle;
import java.awt.Color;
import org.junit.Before;
import org.junit.Test;

/** JUnit test for AnimatorOperations. */
public class AnimationOperationTest {

  // Shapes
  IShape rectangle;
  IShape oval;

  // developerTools
  Point2D point1;
  Point2D point2;
  Screen screen;
  Size size1;
  Size size2;
  TimeInterval timeInterval1;
  TimeInterval timeInterval2;
  TimeInterval timeInterval3;
  Color color1;
  Color color2;

  // AnimatorOperations
  AnimatorOperation move;
  AnimatorOperation paint;
  AnimatorOperation scale;

  /** setUp() method. */
  @Before
  public void setUp() {
    // Component setup
    String rectangleName = "Rectangle_1";
    String ovalName = "Oval_1";
    this.point1 = new Point2D(0, 0);
    this.point2 = new Point2D(-10, -5);
    this.screen = new Screen(10, 20, 100, 200);
    this.size1 = new Size(15, 25);
    this.size2 = new Size(2, 7);
    this.color1 = new Color(200);
    this.color2 = new Color(-1000);
    this.timeInterval1 = new TimeInterval(10, 50);
    this.timeInterval2 = new TimeInterval(20, 70);
    this.timeInterval3 = new TimeInterval(20, 70);

    // Shape instantiation
    this.rectangle =
        new Rectangle(rectangleName, this.point1, this.size1, this.color1, this.timeInterval1);

    this.oval = new Ellipse(ovalName, this.point2, this.size2, this.color2, this.timeInterval2);

    // Move instantiation
    this.move = new Move(this.point2, this.rectangle, this.timeInterval1);
    this.paint = new Paint(this.color2, this.rectangle, this.timeInterval1);
    this.scale = new Scale(this.size2, this.rectangle, this.timeInterval1);
  }

  /** Test getOperationType(). */
  @Test
  public void testGetOperationType() {
    // Test move
    assertEquals(this.move.getOperationType(), OperationType.MOVE);

    // Test paint
    assertEquals(this.paint.getOperationType(), OperationType.PAINT);

    // Test scale
    assertEquals(this.scale.getOperationType(), OperationType.SCALE);
  }

  /** Test getShape(). */
  @Test
  public void testGetShape() {
    // Test move
    assertEquals(this.move.getShape(), this.rectangle);

    // Test paint
    assertEquals(this.paint.getShape(), this.rectangle);

    // Test scale
    assertEquals(this.scale.getShape(), this.rectangle);
  }

  /** Test getTimeInterval(). */
  @Test
  public void testGetTimeInterval() {
    // Test move
    assertEquals(this.move.getTimeInterval(), this.timeInterval1);

    // Test paint
    assertEquals(this.paint.getTimeInterval(), this.timeInterval1);

    // Test scale
    assertEquals(this.scale.getTimeInterval(), this.timeInterval1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testForNull() {
    // Move all 3
    AnimatorOperation moveNull = new Move(null, null, null);
    assertNull(moveNull);

    // Move shape null
    AnimatorOperation moveNull2 = new Move(new Point2D(3, 5), null, new TimeInterval(4, 6));
    assertNull(moveNull2);

    // Move time null
    AnimatorOperation moveNull3 = new Move(new Point2D(4, 6), this.rectangle, null);
    assertNull(moveNull3);

    // Point2D and time null
    AnimatorOperation moveNull4 = new Move(null, this.rectangle, null);
    assertNull(moveNull4);

    // Paint all 3 null
    AnimatorOperation paintNull = new Paint(null, null, null);
    assertNull(paintNull);

    // New color null, time interval
    AnimatorOperation paintNull2 = new Paint(null, this.rectangle, null);
    assertNull(paintNull2);

    // Color and shape null
    AnimatorOperation paintNull3 = new Paint(null, null, new TimeInterval(3, 10));
    assertNull(paintNull3);

    // Point2D and time null
    AnimatorOperation scaleNull = new Scale(null, this.rectangle, null);
    assertNull(scaleNull);

    // Paint all 3 null
    AnimatorOperation scaleNull2 = new Scale(null, null, null);
    assertNull(scaleNull2);

    // New color null, time interval
    AnimatorOperation scaleNull3 = new Scale(null, this.rectangle, null);
    assertNull(scaleNull3);

    // Color and shape null
    AnimatorOperation scaleNull4 = new Scale(null, null, new TimeInterval(3, 10));
    assertNull(scaleNull4);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidColorChange() {
    AnimatorOperation paintBrush2 = new Paint(this.color1, this.rectangle, this.timeInterval1);
    assertEquals("Color cannot be the same", paintBrush2.getShape().getColor().toString());
  }

  @Test
  public void testToString() {
    assertEquals(
        "Shape Rectangle_1 changes color from (0,0,200) to (255,252,24) " + "from t=10 to t=50",
        this.paint.toString());

    assertEquals(
        "Shape Rectangle_1 moves from (0.0,0.0) to (-10.0,-5.0) from t=10 to t=50",
        this.move.toString());

    assertEquals(
        "Shape Rectangle_1 scales from Width: 25.0, Height: 15.0 to Width:"
            + " 7.0, Height: 2.0 from t=10 to t=50",
        this.scale.toString());
  }
}
