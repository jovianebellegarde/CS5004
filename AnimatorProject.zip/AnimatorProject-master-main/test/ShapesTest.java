import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;

import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;
import cs5004.animator.shapes.AbstractShape;
import cs5004.animator.shapes.Ellipse;
import cs5004.animator.shapes.Rectangle;
import cs5004.animator.shapes.ShapeType;
import java.awt.Color;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/** JUnit test for shapes. */
public class ShapesTest {
  /** IllegalArgumentException rule. */
  @Rule public ExpectedException error = ExpectedException.none();

  Rectangle rectangle;
  Ellipse ellipse;

  /** setUp instantiated objects for testing. */
  @Before
  public void setUp() {
    this.rectangle =
        new Rectangle(
            "Rectangle_A",
            new Point2D(0, 1),
            new Size(10, 20),
            new Color(Color.ORANGE.getRGB()),
            new TimeInterval(10, 20));

    this.ellipse =
        new Ellipse(
            "Oval_A",
            new Point2D(15, 23),
            new Size(5, 5),
            new Color(Color.RED.getRGB()),
            new TimeInterval(21, 40));
  }

  /** Testing Rectangle constructor. */
  @Test
  public void testRectangleConstructor() {
    assertNotNull(this.rectangle);
  }

  /** Testing Ellipse constructor. */
  @Test
  public void testOvalConstructor() {
    assertNotNull(this.ellipse);
  }

  /** Testing correct shape types. */
  @Test
  public void testGetShapeType() {
    assertEquals(this.ellipse.getShapeType(), ShapeType.ELLIPSE);
    assertEquals(this.rectangle.getShapeType(), ShapeType.RECTANGLE);
  }

  /** Testing correct color. */
  @Test
  public void testGetColor() {
    assertEquals(this.ellipse.getColor(), Color.RED);
    assertEquals(this.rectangle.getColor(), Color.ORANGE);
  }

  /** Testing correct (x, y) position. */
  @Test
  public void testGetPoint2D() {
    assertEquals(this.ellipse.getPoint2D().getX(), 15, 0.001);
    assertEquals(this.ellipse.getPoint2D().getY(), 23, 0.001);
    assertEquals(this.rectangle.getPoint2D().getX(), 0, 0.001);
    assertEquals(this.rectangle.getPoint2D().getY(), 1, 0.001);
  }

  /** Testing correct sizing. */
  @Test
  public void testGetSize() {
    assertEquals(this.ellipse.getSize().getHeight(), 5, 0.001);
    assertEquals(this.ellipse.getSize().getWidth(), 5, 0.001);
    assertEquals(this.rectangle.getSize().getHeight(), 10, 0.001);
    assertEquals(this.rectangle.getSize().getWidth(), 20, 0.001);
  }

  /** Test copy() method. */
  @Test
  public void testCopy() {
    AbstractShape rectangleCopy = this.rectangle.copy();
    AbstractShape ovalCopy = this.ellipse.copy();
    assertNotSame(rectangleCopy, this.rectangle);
    assertNotSame(ovalCopy, this.ellipse);
  }

  /** Test setPoint2D. */
  @Test
  public void testSetPoint2D() {
    // Positive coordinates
    assertEquals(this.rectangle.getPoint2D().getX(), 3.0, 0.001);
    assertEquals(this.rectangle.getPoint2D().getY(), 2.0, 0.001);

    // Negative coordinates
    assertEquals(this.ellipse.getPoint2D().getX(), -2.0, 0.001);
    assertEquals(this.ellipse.getPoint2D().getY(), -1.0, 0.001);

    // Other two quadrants on Cartesian plane
    assertEquals(this.rectangle.getPoint2D().getX(), 3.0, 0.001);
    assertEquals(this.rectangle.getPoint2D().getY(), -2.0, 0.001);
    assertEquals(this.ellipse.getPoint2D().getX(), -2.0, 0.001);
    assertEquals(this.ellipse.getPoint2D().getY(), 5.0, 0.001);
  }

  /** Test setColor. */
  @Test
  public void testSetColor() {
    assertEquals(this.rectangle.getColor(), Color.DARK_GRAY);
  }

  /** Test setSize. */
  @Test
  public void testSetSize() {
    // Test values > 1
    assertEquals(this.rectangle.getSize().getHeight(), 200.0, 0.001);
    assertEquals(this.rectangle.getSize().getWidth(), 200.0, 0.001);

    // Test values < 1
    assertEquals(this.rectangle.getSize().getHeight(), 0.2, 0.001);
    assertEquals(this.rectangle.getSize().getWidth(), 0.5, 0.001);

    // Test invalid Sizes
    error.expect(IllegalArgumentException.class);
  }

  /** Test toString(). */
  @Test
  public void testToString() {
    String stringRect =
        "Name: Rectangle_A\n"
            + "Type: rectangle\n"
            + "Min corner: (0.0,1.0), Width: 20.0, Height: 10.0, Color: (255,200,0)\n"
            + "Appears at t=10\n"
            + "Disappears at t=20\n";

    String stringOval =
        "Name: Oval_A\n"
            + "Type: ellipse\n"
            + "Center: (15.0,23.0), X radius: 2.5, Y radius: 2.5, Color: (255,0,0)\n"
            + "Appears at t=21\n"
            + "Disappears at t=40\n";

    assertEquals(stringRect, this.rectangle.toString());
    assertEquals(stringOval, this.ellipse.toString());
  }
}
