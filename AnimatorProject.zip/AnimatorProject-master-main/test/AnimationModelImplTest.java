import static org.junit.Assert.assertEquals;

import cs5004.animator.animatorOperations.AnimatorOperation;
import cs5004.animator.animatorOperations.Move;
import cs5004.animator.animatorOperations.Paint;
import cs5004.animator.animatorOperations.Scale;
import cs5004.animator.model.AnimationModelImpl;
import cs5004.animator.model.IAnimationModel;
import cs5004.animator.shapes.Ellipse;
import cs5004.animator.shapes.IShape;
import cs5004.animator.shapes.Rectangle;
import cs5004.animator.util.Screen;
import cs5004.animator.util.Point2D;
import cs5004.animator.util.Size;
import cs5004.animator.util.TimeInterval;
import java.awt.Color;
import java.util.function.BiFunction;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/** JUnit test for AnimationModel implementation. */
public class AnimationModelImplTest {
  /** For exceptions. */
  @Rule public ExpectedException error = ExpectedException.none();

  // Shapes
  IShape rectangle1;
  IShape rectangle2;
  IShape oval1;
  IShape oval2;

  // developerTools
  Point2D point1;
  Point2D point2;
  Screen screen;
  Size size1;
  Size size2;
  TimeInterval timeIntervalShapeR;
  TimeInterval timeIntervalShapeO;
  Color color1;
  Color color2;

  // AnimatorOperations
  AnimatorOperation move;
  AnimatorOperation paint;
  AnimatorOperation scale;

  // AnimationModel
  IAnimationModel animationModel;

  @Before
  public void setUp() {
    // Component setup
    String rectangleName = "Rectangle_1";
    String ovalName = "Oval_1";
    this.point1 = new Point2D(0, 0);
    this.point2 = new Point2D(-10, -5);
    this.screen = new Screen(10, 20, 100, 200);
    this.size1 = new Size(15, 25);
    this.size2 = new Size(2, 7);
    this.color1 = new Color(200);
    this.color2 = new Color(-1000);
    this.timeIntervalShapeR = new TimeInterval(4, 100);
    this.timeIntervalShapeO = new TimeInterval(7, 110);

    // Shape instantiation
    this.rectangle1 =
        new Rectangle(rectangleName, this.point1, this.size1, this.color1, this.timeIntervalShapeR);

    this.rectangle2 =
        new Rectangle("Rectangle_2", this.point2, this.size2, this.color2, this.timeIntervalShapeO);

    this.oval1 =
        new Ellipse(ovalName, this.point2, this.size2, this.color2, this.timeIntervalShapeO);
    this.oval2 =
        new Ellipse("Oval_2", this.point1, this.size1, this.color1, this.timeIntervalShapeR);

    // Move instantiation
    this.move = new Move(this.point2, this.rectangle1, new TimeInterval(5, 70));
    this.paint = new Paint(this.color2, this.rectangle1, new TimeInterval(71, 75));
    this.scale = new Scale(this.size2, this.rectangle1, new TimeInterval(76, 99));

    // Animation Model implementation
    this.animationModel = new AnimationModelImpl();

    // List of AnimationOperations
    this.animationModel.addAnimation(this.move);
    this.animationModel.addAnimation(this.paint);
    this.animationModel.addAnimation(this.scale);

    // Map of Shape objects
    this.animationModel.addShape(this.rectangle1);
    this.animationModel.addShape(this.oval1);
  }

  /** Test getShapesMap() method. */
  @Test
  public void testGetShapesMap() {
    assertEquals(
        "{Rectangle_1=Name: Rectangle_1\n"
            + "Type: rectangle\n"
            + "Min corner: (0.0,0.0), Width: 25.0, Height: 15.0, Color: (0,0,200)\n"
            + "Appears at t=4\n"
            + "Disappears at t=100\n"
            + ", Oval_1=Name: Oval_1\n"
            + "Type: ellipse\n"
            + "Center: (-10.0,-5.0), X radius: 3.5, Y radius: 1.0, Color: (255,252,24)\n"
            + "Appears at t=7\n"
            + "Disappears at t=110\n"
            + "}",
        this.animationModel.getShapesMap().toString());
  }

  /** Test getAnimationList() method. */
  @Test
  public void testGetAnimationList() {
    assertEquals(
        "[Shape Rectangle_1 moves from (0.0,0.0) to (-10.0,-5.0) from "
            + "t=5 to t=70, Shape Rectangle_1 changes color from (0,0,200) to "
            + "(255,252,24) from t=71 to t=75, Shape Rectangle_1 scales from "
            + "Width: 25.0, Height: 15.0 to Width: 7.0, Height: 2.0 from t=76 "
            + "to t=99]",
        this.animationModel.getTransformationList().toString());
  }

  /** Test addShape() method. */
  @Test
  public void testAddShape() {
    // Add rectangle
    this.animationModel.addShape(this.rectangle2);
    // Add ellipse
    this.animationModel.addShape(this.oval2);
    // There should be four shapes in HashMap
    assertEquals(4, this.animationModel.getShapesMap().size());

    // Cannot add Shapes with same memory addresses
    error.expect(IllegalArgumentException.class);
    this.animationModel.addShape(this.oval2);
  }

  /** Test addShape() method. */
  @Test
  public void testRemoveShape() {
    // Add rectangle
    this.animationModel.addShape(this.rectangle2);
    // Add ellipse
    this.animationModel.addShape(this.oval2);

    // Remove one item
    this.animationModel.removeShape("Oval_1");
    // There should be three shapes in HashMap
    assertEquals(3, this.animationModel.getShapesMap().size());

    // Attempt to remove an item that does not exist in the shapesMap
    error.expect(IllegalArgumentException.class);
    this.animationModel.removeShape("Rhombus_5");
    assertEquals(3, this.animationModel.getShapesMap().size());
  }

  /** Test addShape() method. */
  @Test
  public void testAddAnimation() {
    AnimatorOperation move1 = new Move(this.point2, this.rectangle1, new TimeInterval(5, 70));
    AnimatorOperation paint1 = new Paint(this.color2, this.rectangle1, new TimeInterval(71, 75));
    AnimatorOperation scale1 = new Scale(this.size2, this.rectangle1, new TimeInterval(76, 99));

    // Added three additional objects
    this.animationModel.addAnimation(move1);
    this.animationModel.addAnimation(paint1);
    this.animationModel.addAnimation(scale1);

    assertEquals(6, this.animationModel.getTransformationList().size());
  }

  /** Test addShape() method. */
  @Test
  public void testGetShapesAtTime() {
    // Should be two Shapes at t=10
    assertEquals(2, this.animationModel.getShapesAtTime(10).size());
  }

  // Deleted
//  /** Test addShape() method. */
//  @Test
//  public void testFold() {
//    // "Seed" means the starting point or root/accumulator
//    // Seed acts like a temporary variable
//    // There are two variables, the AnimationOperation and String/seed. The first two
//    // arguments are the inputs for the BiFunction and the last argument
//    // (String) is the return type!
//
//    BiFunction<AnimatorOperation, Integer, Integer> longestOperation =
//        (animatorOperation, seed) ->
//            animatorOperation.getTimeInterval().getTimeElapsed() > seed
//                ? animatorOperation.getTimeInterval().getTimeElapsed()
//                : seed;
//
//    int longestOperationTime = this.animationModel.fold(longestOperation, 0); /
//
//     The longest AnimatorOperation should be Move with a total elapsed time of 65
//    assertEquals(65, longestOperationTime);
//  }

  /** Verify null checks. */
  @Test(expected = IllegalArgumentException.class)
  public void testNulls() {
    this.animationModel.addAnimation(new Move(null, null, null));
    this.animationModel.addAnimation(new Paint(null, null, null));
    this.animationModel.addAnimation(new Scale(null, null, null));
  }

  /** Test toString() method. */
  @Test
  public void testToString() {
    assertEquals(
        "Shapes:\n"
            + "Name: Rectangle_1\n"
            + "Type: rectangle\n"
            + "Min corner: (0.0,0.0), Width: 25.0, Height: 15.0, Color: (0,0,200)\n"
            + "Appears at t=4\n"
            + "Disappears at t=100\n"
            + "\n"
            + "Name: Oval_1\n"
            + "Type: ellipse\n"
            + "Center: (-10.0,-5.0), X radius: 3.5, Y radius: 1.0, Color: (255,252,24)\n"
            + "Appears at t=7\n"
            + "Disappears at t=110\n"
            + "\n"
            + "Shape Rectangle_1 moves from (0.0,0.0) to (-10.0,-5.0) from t=5 to t=70\n"
            + "\n"
            + "Shape Rectangle_1 changes color from (0,0,200) to (255,252,24) "
            + "from t=71 to t=75\n"
            + "\n"
            + "Shape Rectangle_1 scales from Width: 25.0, Height: 15.0 to Width: "
            + "7.0, Height: 2.0 from t=76 to t=99\n"
            + "\n",
        this.animationModel.toString());
  }
}
